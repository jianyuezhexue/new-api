var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/[lang]/llm.txt/route.js")
R.c("server/chunks/[root-of-the-server]__36d0be8d._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/_0fb51f2b._.js")
R.c("server/chunks/node_modules_877d9434._.js")
R.c("server/chunks/_next-internal_server_app_[lang]_llm_txt_route_actions_462896ed.js")
R.m(102092)
module.exports=R.m(102092).exports
