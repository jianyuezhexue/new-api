var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/[lang]/llms-full.txt/route.js")
R.c("server/chunks/[root-of-the-server]__ff357df6._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/_0fb51f2b._.js")
R.c("server/chunks/node_modules_877d9434._.js")
R.c("server/chunks/_next-internal_server_app_[lang]_llms-full_txt_route_actions_e2028c56.js")
R.m(662140)
module.exports=R.m(662140).exports
