var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/[lang]/llms.mdx/[[...slug]]/route.js")
R.c("server/chunks/[root-of-the-server]__18efbcc0._.js")
R.c("server/chunks/node_modules_next_dist_bad7315a._.js")
R.c("server/chunks/_4eea202f._.js")
R.c("server/chunks/node_modules_877d9434._.js")
R.c("server/chunks/[root-of-the-server]__e3ecfd17._.js")
R.c("server/chunks/_next-internal_server_app_[lang]_llms_mdx_[[___slug]]_route_actions_e35c2dd9.js")
R.m(994250)
module.exports=R.m(994250).exports
