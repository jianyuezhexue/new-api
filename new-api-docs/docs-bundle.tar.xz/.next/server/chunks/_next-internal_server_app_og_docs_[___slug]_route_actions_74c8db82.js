module.exports=[892421,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_og_docs_%5B___slug%5D_route_actions_74c8db82.js.map