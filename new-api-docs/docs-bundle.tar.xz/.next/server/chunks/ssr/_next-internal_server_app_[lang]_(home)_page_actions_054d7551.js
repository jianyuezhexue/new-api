module.exports=[20480,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_%5Blang%5D_%28home%29_page_actions_054d7551.js.map