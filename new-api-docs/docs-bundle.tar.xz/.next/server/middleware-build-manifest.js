globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/6a101d57b0fd6a4b.js",
    "static/chunks/d85498f20e59bb7c.js",
    "static/chunks/08dcfc3b15383cd6.js",
    "static/chunks/f116dc912b2ffba2.js",
    "static/chunks/5c0edd4cdf7c4cd6.js",
    "static/chunks/turbopack-0e2b6cb6c668bdf6.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];